package com.demoblaze.e2e.tests;

import com.demoblaze.e2e.pages.CartPage;
import com.demoblaze.e2e.pages.CheckoutPage;
import com.demoblaze.e2e.pages.HomePage;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class PurchaseFlowTest {

    private WebDriver driver;
    private HomePage homePage;
    private CartPage cartPage;
    private CheckoutPage checkoutPage;

    private static final String URL_DEMOBLAZE = "https://www.demoblaze.com/";

    @BeforeMethod
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        homePage = new HomePage(driver);
        cartPage = new CartPage(driver);
        checkoutPage = new CheckoutPage(driver);
    }

    @Test
    public void testPurchaseFlow() throws InterruptedException { 
        homePage.navigateToHomePage(URL_DEMOBLAZE);

        // 1. Agregar el primer producto
        homePage.addProductToCart("Samsung galaxy s6"); 
        homePage.confirmProductAdded();

        // REGRESAR A LA PÁGINA PRINCIPAL para ver otros productos
        homePage.navigateToHomePage(URL_DEMOBLAZE);

        // 2. Agregar el segundo producto
        homePage.addProductToCart("Nokia lumia 1520"); 
        homePage.confirmProductAdded();

        // 3. Visualizar el carrito
        homePage.navigateToCart();

        //Thread.sleep(10000); // Pausa de 10 segundos para poder ver el carrito

        Assert.assertTrue(cartPage.isProductInCart("Samsung galaxy s6"), "Samsung galaxy s6 should be in cart");
        Assert.assertTrue(cartPage.isProductInCart("Nokia lumia 1520"), "Nokia lumia 1520 should be in cart");

        // 4. Completar el formulario de compra
        cartPage.placeOrder();
        checkoutPage.fillOrderForm("Luis Cabrera", "Ecuador", "Guayaquil", "1234567890123456", "12", "2025");

        // 5. Finalizar la compra
        checkoutPage.purchaseOrder();

        // 6. Verificar la compra y cerrar el popup
        Assert.assertTrue(checkoutPage.isPurchaseConfirmed(), "Purchase should be confirmed.");
       
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}