package com.demoblaze.e2e.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class CheckoutPage {
    private WebDriver driver;
    private WebDriverWait wait;

    private By nameField = By.id("name");
    private By countryField = By.id("country");
    private By cityField = By.id("city");
    private By creditCardField = By.id("card");
    private By monthField = By.id("month");
    private By yearField = By.id("year");
    private By purchaseButton = By.xpath("//button[text()='Purchase']");
    private By confirmationMessage = By.xpath("//h2[text()='Thank you for your purchase!']");
    private By okButton = By.xpath("//button[text()='OK']");

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void fillOrderForm(String name, String country, String city, String creditCard, String month, String year) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(nameField)).sendKeys(name); 
        driver.findElement(countryField).sendKeys(country);
        driver.findElement(cityField).sendKeys(city);
        driver.findElement(creditCardField).sendKeys(creditCard);
        driver.findElement(monthField).sendKeys(month);
        driver.findElement(yearField).sendKeys(year);
    }

    public void purchaseOrder() {
        wait.until(ExpectedConditions.elementToBeClickable(purchaseButton)).click(); 
        // Esperar a que el modal de confirmación aparezca después de hacer clic en Purchase
        wait.until(ExpectedConditions.visibilityOfElementLocated(confirmationMessage));
    }

    public boolean isPurchaseConfirmed() {
        // Ahora solo verificamos que esté visible y luego cerramos.
        boolean isConfirmed = driver.findElement(confirmationMessage).isDisplayed();
        wait.until(ExpectedConditions.elementToBeClickable(okButton)).click(); // Cierra el pop-up y espera a que el botón sea clicable
        wait.until(ExpectedConditions.invisibilityOfElementLocated(confirmationMessage));
        return isConfirmed;
    }

    public String getConfirmationText() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(confirmationMessage)).getText();
    }
}