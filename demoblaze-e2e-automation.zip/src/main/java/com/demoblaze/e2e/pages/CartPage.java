package com.demoblaze.e2e.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class CartPage {
    private WebDriver driver;
    private WebDriverWait wait;

    private By placeOrderButton = By.xpath("//button[text()='Place Order']");
    private By cartTableBody = By.id("tbodyid"); 

    public CartPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public boolean isProductInCart(String productName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cartTableBody));

        By productInCartLocator = By.xpath("//tbody[@id='tbodyid']//td[contains(text(), '" + productName + "')]");

        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(productInCartLocator));
            System.out.println("DEBUG: Producto '" + productName + "' ENCONTRADO en el carrito."); 
            return true;
        } catch (org.openqa.selenium.TimeoutException e) {
            System.out.println("DEBUG: Producto '" + productName + "' NO encontrado en el carrito en el tiempo esperado."); 
            return false;
        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("DEBUG: Producto '" + productName + "' no existe en el DOM del carrito."); 
            return false;
        }
    }

    public void placeOrder() {
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderButton)).click();
    }

    public int getNumberOfProductsInCart() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cartTableBody));
        List<WebElement> productRows = driver.findElements(By.cssSelector("#tbodyid tr"));
        return productRows.size();
    }
}