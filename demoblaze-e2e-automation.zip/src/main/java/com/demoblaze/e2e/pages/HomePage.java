package com.demoblaze.e2e.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class HomePage {
    private WebDriver driver;
    private WebDriverWait wait;

    private By addToCartButton = By.xpath("//a[text()='Add to cart']");
    private By cartLink = By.id("cartur"); 
    private By productStoreLogo = By.id("nava"); 

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void navigateToHomePage(String url) {
        driver.get(url);
        wait.until(ExpectedConditions.visibilityOfElementLocated(productStoreLogo)); 
    }

    public void addProductToCart(String productName) {
        wait.until(ExpectedConditions.elementToBeClickable(By.linkText(productName))).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartButton));
        driver.findElement(addToCartButton).click();
    }

    public void confirmProductAdded() {
        wait.until(ExpectedConditions.alertIsPresent());
        driver.switchTo().alert().accept();
    }

    public void navigateToCart() {
        // 1. Espera a que el enlace 'Cart' sea clicable y haz clic.
        wait.until(ExpectedConditions.elementToBeClickable(cartLink)).click();
        
        // 2. Después de hacer clic, espera a que la URL cambie a la página del carrito.
        wait.until(ExpectedConditions.urlContains("cart.html"));
      
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Place Order']")));
    }
}