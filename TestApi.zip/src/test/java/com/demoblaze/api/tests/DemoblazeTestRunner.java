package com.demoblaze.api.tests;

import com.intuit.karate.junit5.Karate;
import org.junit.jupiter.api.BeforeAll; // Aunque no lo uses, es buena práctica si el método setup está ahí

class DemoblazeTestRunner {

    // Opcional: si necesitas alguna configuración global antes de todas las pruebas
    // @BeforeAll
    // static void setup() {
    //     System.setProperty("karate.env", "qa"); // Ejemplo de cómo pasar una variable de entorno
    // }

    @Karate.Test
    Karate testDemoblazeFeatures() {
        // Especificar directamente los archivos .feature que se van a ejecutar.
        // La ruta es relativa a la raíz del classpath de pruebas (target/test-classes).
        // Esto es un último recurso cuando el escaneo automático de Karate.run() falla inexplicablemente.
        return Karate.run("classpath:demoblaze.feature", "classpath:test.feature");
    }
}